#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo 'Open http://127.0.0.1:8000; configure .env for live QuickNode data.'
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
