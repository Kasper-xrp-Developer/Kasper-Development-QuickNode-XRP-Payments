@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 (echo Python 3 is required. & pause & exit /b 1)
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (echo Dependency installation failed. Check internet and Python installation. & pause & exit /b 1)
if not exist ".env" copy ".env.example" ".env" >nul
echo Open http://127.0.0.1:8000 in your browser.
echo Configure .env with your QuickNode XRPL Testnet URL for live blockchain data.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
