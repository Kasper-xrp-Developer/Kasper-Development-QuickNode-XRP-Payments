# Kasper XRP Nexus — QuickNode XRPL Testnet Starter

A runnable FastAPI backend and responsive browser dashboard for XRPL Testnet using QuickNode JSON-RPC. Includes XRP account lookup, RLUSD trust-line lookup, validated-ledger monitoring (15-second polling), fee and health queries, transaction verification, and **non-executing** AI/human payment-intent policy evaluation.

## Important security boundaries

- **No private keys, seed phrases, signing, trust-line creation, or transaction submission.** The payment gateway is a policy evaluation/proposal demo, not a live payment processor. Approval endpoint explicitly returns 501.
- All payment intents stay in **memory** and disappear on restart. Do not use this store for production financial controls.
- RLUSD requires a *verified Testnet issuer* and a trust line created independently. Issuer is intentionally not hardcoded.
- QuickNode endpoint must point to **XRPL Testnet**. The app checks reported network ID when present, but some RPC providers omit it: verify your endpoint in QuickNode dashboard.
- Never expose the QuickNode URL to browsers, logs, screenshots, or source control. Do not commit `.env`.
- No login/authentication: run locally only. Before public deployment add authentication, database, CSRF protections, durable idempotency, auditable approval workflows, proper key custody, signing review, WebSocket/Streams, and rate limiting.

## Windows setup (PowerShell)

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 and API docs at http://127.0.0.1:8000/docs.

## Configure `.env`

1. Open https://dashboard.quicknode.com/ and locate your XRPL **Testnet** endpoint.
2. Paste the complete **HTTPS** JSON-RPC endpoint URL into `QUICKNODE_XRPL_HTTP_URL`. Do not use the dashboard page URL.
3. Independently verify the **Testnet** RLUSD issuer address and paste it into `RLUSD_ISSUER_TESTNET`. Verify currency encoding with the issuer/network documentation.
4. Add a comma-separated list of permitted XRPL classic addresses to `DESTINATION_ALLOWLIST`.
5. Keep `XRPL_NETWORK=testnet` and adjust policy limits if needed.

## Example API calls

```bash
curl http://127.0.0.1:8000/api/config
curl http://127.0.0.1:8000/api/health
curl http://127.0.0.1:8000/api/fee
curl http://127.0.0.1:8000/api/monitor
curl -X POST http://127.0.0.1:8000/api/intents -H 'Content-Type: application/json' -d '{"destination":"REPLACE_WITH_ALLOWLISTED_CLASSIC_ADDRESS","amount":"1.25","agent":"ai"}'
```

The intent request only returns `pending_approval` or `blocked`; it never moves money.

## Tests

```bash
pytest -q
```

Tests are offline and do not require a QuickNode account. The real RPC calls require a configured live Testnet endpoint and internet access.

## Architecture

Browser → FastAPI → QuickNode XRPL JSON-RPC → XRPL Testnet. Separate policy engine checks amount and allowlist before recording an intent. Monitoring is polling, not push subscriptions. The starter's 'AI agent' is a typed agent intent, not an LLM integration.

## Production next steps

Use a database with transactional reservations for budget enforcement, signed/authenticated approval with RBAC, server-side agent identity, replay protection, independent payment validation, safe transaction construction and hardware/HSM signing, explicit ledger settlement confirmation, and robust monitoring. Do not enable automated spending without these controls.

## One-click startup
On Windows double-click `start_windows.bat` (Python 3 and internet for first-time dependency installation required). On macOS/Linux run `bash start_linux_mac.sh`. The dashboard opens at `http://127.0.0.1:8000` after the server starts. It works without credentials for local policy demo; live blockchain data requires the QuickNode endpoint in `.env`.
