"""Kasper XRP Nexus: read-only XRPL monitor and policy-gated payment intent demo.
No seed, private key, or signing functionality is accepted or stored.
"""
import os
import re
import secrets
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Literal

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

load_dotenv()
BASE = Path(__file__).resolve().parent.parent
app = FastAPI(title="Kasper XRP Nexus", version="0.1.0", description="XRPL Testnet monitoring and safe payment-intent demo")
INTENTS: dict[str, dict] = {}  # Demo only: memory; reset on restart
ADDRESS = re.compile(r"^r[1-9A-HJ-NP-Za-km-z]{24,34}$")


def config():
    return {
        "rpc": os.getenv("QUICKNODE_XRPL_HTTP_URL", "").strip(),
        "network": os.getenv("XRPL_NETWORK", "testnet").strip().lower(),
        "issuer": os.getenv("RLUSD_ISSUER_TESTNET", "").strip(),
        "currency": os.getenv("RLUSD_CURRENCY_CODE", "524C555344000000000000000000000000000000").strip(),
        "max_payment": Decimal(os.getenv("MAX_PAYMENT_RLUSD", "10")),
        "daily_budget": Decimal(os.getenv("DAILY_BUDGET_RLUSD", "25")),
        "allowlist": {x.strip() for x in os.getenv("DESTINATION_ALLOWLIST", "").split(",") if x.strip()},
    }


def guard_network():
    cfg = config()
    if cfg["network"] != "testnet":
        raise HTTPException(503, "Only testnet is permitted in this starter")
    if not cfg["rpc"].startswith("https://"):
        raise HTTPException(503, "Configure QUICKNODE_XRPL_HTTP_URL as an HTTPS Testnet endpoint")
    return cfg


async def rpc(method: str, params: dict | None = None):
    cfg = guard_network()
    try:
        async with httpx.AsyncClient(timeout=12.0, follow_redirects=False) as client:
            response = await client.post(cfg["rpc"], json={"method": method, "params": [params or {}]})
            response.raise_for_status()
            payload = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise HTTPException(502, f"XRPL RPC unavailable: {type(exc).__name__}") from exc
    result = payload.get("result", {})
    if not isinstance(result, dict) or result.get("error") or payload.get("error"):
        raise HTTPException(502, f"XRPL RPC error: {result.get('error', payload.get('error', 'invalid response'))}")
    return result


class IntentRequest(BaseModel):
    destination: str
    amount: str = Field(description="Positive RLUSD amount as decimal string")
    note: str = Field(default="", max_length=160)
    agent: Literal["human", "ai"] = "human"


def parse_amount(value: str) -> Decimal:
    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise HTTPException(422, "Invalid decimal amount") from exc
    if not amount.is_finite() or amount <= 0 or amount.as_tuple().exponent < -6:
        raise HTTPException(422, "Amount must be positive with at most six decimal places")
    return amount


def evaluate(req: IntentRequest, now=None):
    cfg = config()
    amount = parse_amount(req.amount)
    reasons = []
    if cfg["network"] != "testnet":
        reasons.append("Only XRPL Testnet is allowed")
    if not ADDRESS.fullmatch(req.destination):
        reasons.append("Destination must be an XRPL classic address")
    if not cfg["allowlist"] or req.destination not in cfg["allowlist"]:
        reasons.append("Destination not present in the configured allowlist")
    if amount > cfg["max_payment"]:
        reasons.append("Payment exceeds per-payment policy limit")
    if not ADDRESS.fullmatch(cfg["issuer"]):
        reasons.append("A verified Testnet RLUSD issuer must be configured")
    day = (now or datetime.now(timezone.utc)).date().isoformat()
    spent = sum(Decimal(x["amount"]) for x in INTENTS.values() if x["date"] == day and x["status"] in ("approved", "exported"))
    if spent + amount > cfg["daily_budget"]:
        reasons.append("Payment exceeds daily approved-intent budget")
    return reasons, day


@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")


@app.get("/api/config")
def public_config():
    cfg = config()
    return {"network": cfg["network"], "asset": "RLUSD", "rpc_configured": bool(cfg["rpc"]), "issuer_configured": bool(cfg["issuer"]), "allowlist_count": len(cfg["allowlist"]), "signing_enabled": False}


@app.get("/api/health")
async def health():
    info = await rpc("server_info")
    server = info.get("info", {})
    if server.get("network_id") not in (None, 1):
        # XRPL Testnet is normally network ID 1; reject clear mismatch.
        raise HTTPException(503, "Endpoint reports a non-Testnet network ID")
    return {"ok": True, "network": "testnet", "server_state": server.get("server_state"), "validated_ledger": server.get("validated_ledger"), "network_id": server.get("network_id")}


@app.get("/api/ledger")
async def ledger():
    return await rpc("ledger", {"ledger_index": "validated", "transactions": False, "expand": False})


@app.get("/api/fee")
async def fee():
    return await rpc("fee")


@app.get("/api/account/{address}")
async def account(address: str):
    if not ADDRESS.fullmatch(address):
        raise HTTPException(422, "Invalid XRPL classic address")
    return await rpc("account_info", {"account": address, "ledger_index": "validated"})


@app.get("/api/rlusd/{address}")
async def rlusd(address: str):
    if not ADDRESS.fullmatch(address):
        raise HTTPException(422, "Invalid XRPL classic address")
    cfg = guard_network()
    if not ADDRESS.fullmatch(cfg["issuer"]):
        raise HTTPException(503, "Set a verified RLUSD_ISSUER_TESTNET")
    result = await rpc("account_lines", {"account": address, "peer": cfg["issuer"], "ledger_index": "validated"})
    return {"account": address, "issuer": cfg["issuer"], "lines": [x for x in result.get("lines", []) if x.get("currency", "").upper() in ("RLUSD", cfg["currency"].upper())]}


@app.get("/api/tx/{tx_hash}")
async def transaction(tx_hash: str):
    if not re.fullmatch(r"[A-Fa-f0-9]{64}", tx_hash):
        raise HTTPException(422, "Invalid transaction hash")
    result = await rpc("tx", {"transaction": tx_hash, "binary": False})
    return {"hash": tx_hash.upper(), "validated": result.get("validated", False), "result": result.get("meta", {}).get("TransactionResult") if isinstance(result.get("meta"), dict) else None, "ledger_index": result.get("ledger_index")}


@app.post("/api/intents")
def create_intent(req: IntentRequest):
    reasons, day = evaluate(req)
    intent_id = secrets.token_urlsafe(16)
    intent = {"id": intent_id, "destination": req.destination, "amount": str(parse_amount(req.amount)), "asset": "RLUSD", "note": req.note, "agent": req.agent, "date": day, "status": "blocked" if reasons else "pending_approval", "reasons": reasons}
    INTENTS[intent_id] = intent
    return intent


@app.get("/api/intents")
def list_intents():
    return list(INTENTS.values())


@app.post("/api/intents/{intent_id}/approve")
def approve(intent_id: str):
    # Starter deliberately has no authenticated approval system; cannot authorize spending.
    raise HTTPException(501, "Approval and signing are disabled until authenticated human review is implemented")


@app.get("/api/monitor")
async def monitor():
    """Polling-friendly snapshot; not a stream subscription."""
    result = await rpc("ledger", {"ledger_index": "validated", "transactions": False})
    led = result.get("ledger", {})
    return {"ledger_index": led.get("ledger_index"), "close_time": led.get("close_time"), "ledger_hash": led.get("ledger_hash"), "validated": result.get("validated", False)}
