import os
from fastapi.testclient import TestClient
from app.main import app, INTENTS

client = TestClient(app)
DEST = "r" + "a" * 25
ISSUER = "r" + "b" * 25


def setup_function():
    INTENTS.clear()
    os.environ["XRPL_NETWORK"] = "testnet"
    os.environ["RLUSD_ISSUER_TESTNET"] = ISSUER
    os.environ["DESTINATION_ALLOWLIST"] = DEST
    os.environ["MAX_PAYMENT_RLUSD"] = "10"
    os.environ["DAILY_BUDGET_RLUSD"] = "25"


def test_home():
    assert client.get("/").status_code == 200


def test_config_does_not_expose_endpoint():
    os.environ["QUICKNODE_XRPL_HTTP_URL"] = "https://private.example/secret-token"
    assert "secret-token" not in client.get("/api/config").text


def test_valid_intent_requires_human_approval():
    r = client.post("/api/intents", json={"destination": DEST, "amount": "2", "agent": "ai"})
    assert r.status_code == 200
    assert r.json()["status"] == "pending_approval"
    assert client.post("/api/intents/" + r.json()["id"] + "/approve").status_code == 501


def test_non_allowlisted_blocked():
    r = client.post("/api/intents", json={"destination": ISSUER, "amount": "2"})
    assert r.json()["status"] == "blocked"


def test_large_payment_blocked():
    r = client.post("/api/intents", json={"destination": DEST, "amount": "11"})
    assert r.json()["status"] == "blocked"


def test_invalid_amount_rejected():
    for amount in ("0", "-1", "NaN", "1.1234567", "abc"):
        assert client.post("/api/intents", json={"destination": DEST, "amount": amount}).status_code == 422


def test_mainnet_blocked():
    os.environ["XRPL_NETWORK"] = "mainnet"
    r = client.post("/api/intents", json={"destination": DEST, "amount": "1"})
    assert r.json()["status"] == "blocked"


def test_bad_account_address():
    assert client.get("/api/account/invalid").status_code == 422


def test_bad_tx_hash():
    assert client.get("/api/tx/123").status_code == 422
